package bolts;

public class Airport
{
    //airports: city, code, latitude, and longitude.
    String city;
    String code;
    String latitude;
    String longitude;

    public String getCity() {
        return city;
    }

    public String getCode() {
        return code;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }

}